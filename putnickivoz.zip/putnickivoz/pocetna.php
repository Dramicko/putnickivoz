<?php
include 'config.php'; // Uključivanje konfiguracije za bazu podataka
session_start();
?>
<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <title>Početna strana</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .navbar-custom {
            background-color: #0056b3; /* Tamnija nijansa plave */
            box-shadow: 0 2px 4px rgba(0,0,0,.1);
        }
        .card-custom {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,.1);
        }
        .card-header-custom {
            background-color: #007bff;
            color: white;
            border-radius: 10px 10px 0 0;
        }
        .btn-custom {
            background-color: #28a745;
            border: none;
        }
        html, body {
            height: 100%; /* Postavlja visinu HTML-a i BODY-a na 100% */
            margin: 0;
            padding: 0;
        }
        .content {
            min-height: calc(100vh - 60px); /* Visina sadržaja je 100% viewport-a minus visina footera */
            padding: 20px; /* Dodaje padding za sadržaj */
        }
        footer {
            position: relative;
            bottom: 0;
            width: 100%; /* Širina footera je 100% */
            background-color: #0056b3;
            color: white;
            padding: 20px 0;
            text-align: center;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
        <div class="container-fluid">
            <a class="navbar-brand" href="pocetna.php">Putnicki Voz</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
          
                <div class="d-flex ms-auto">
                    <?php
                    if (isset($_SESSION['username'])) {
                        echo '<a href="logout.php" class="btn btn-outline-light">Odjavi se</a>';
                    }
                    ?>
                </div>
            </div>
        </div>
    </nav>

    <div class="content">
        <div class="container mt-4">
            <h2 class="mb-4">Vozovi i redosled vožnje</h2>
            <div class="row row-cols-1 row-cols-md-3 g-4">
                <?php
                $result = $conn->query("SELECT RedosledVoznje.*, Vozovi.NazivVoz, RedosledVoznje.Cena FROM RedosledVoznje JOIN Vozovi ON RedosledVoznje.VozID = Vozovi.VozID");
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="col">
                            <div class="card card-custom h-100">
                                <div class="card-header card-header-custom">Voz: ' . $row['NazivVoz'] . '</div>
                                <div class="card-body">
                                    <h5 class="card-title">Od: ' . $row['PolaznaStanica'] . ' Do: ' . $row['DolaznaStanica'] . '</h5>
                                    <p class="card-text">Polazak: ' . $row['Polazak'] . '</p>
                                    <p class="card-text">Dolazak: ' . $row['Dolazak'] . '</p>
                                    <p class="card-text">Cena: ' . $row['Cena'] . ' RSD</p>
                                    <a href="rezervacija.php?redosledID=' . $row['RedosledID'] . '" class="btn btn-custom">Rezerviši kartu</a>
                                </div>
                            </div>
                        </div>';
                }
                ?>
            </div>
        </div>
    </div>

    <footer>
        <div class="container-fluid py-3">
            <p class="text-center mb-0">Copyright &copy; 2024 Putnicki Voz</p>
        </div>
    </footer>
</body>
</html>
