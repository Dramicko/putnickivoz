<?php
session_start(); // Pokretanje sesije
session_destroy(); // Uništavanje sesije
header("Location: index.php"); // Preusmeravanje na početnu stranicu
exit;
?>

