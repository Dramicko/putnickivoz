<?php
include 'config.php'; // Uključivanje konfiguracije za bazu podataka

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];

    // Provera korisnika u bazi
    $sql = "SELECT lozinka FROM Korisnici WHERE korisnicko_ime='$username'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['lozinka'])) {
            session_start();
            $_SESSION['username'] = $username;
            header("Location: pocetna.php");
            exit;
        } else {
            echo "Pogrešna lozinka!";
        }
    } else {
        echo "Korisničko ime ne postoji!";
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="sr">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('slike/poz2.jpg');
            background-size: cover;
            background-position: center;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Login</h1>
        <form method="post">
            <div class="mb-3">
                <label for="username" class="form-label">Korisničko ime:</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Lozinka:</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Uloguj se</button>
            <button type="button" class="btn btn-secondary w-100 mt-3" onclick="window.location='register.php';">Registruj se</button>
        </form>
    </div>
</body>
</html>
